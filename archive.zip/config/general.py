# Version of backend
BACKEND_API_VER: str = "0.0.1"
