DB_HOST: str = 'localhost'
DB_NAME: str = 'ahu_elec_watch'
DB_USERNAME: str = 'ahu_elec_watch'
DB_PASSWORD: str = 'ahu_elec_watch'
